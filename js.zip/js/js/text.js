//$(function(){  
//	var t;   //图片轮播
//	var index=0;
//	t=setInterval(play,2000)//添加定时器，循环调用
//	function play(){
//		index++;
//		if(index>4){
//			index=0
//		}
//		$("#tt li").eq(index).fadeIn().siblings().fadeOut();
//	}
// })

//$(function(){
//	var y;
//	var index=0;
//	y=setInterval(sum,2000);
//	function sum(){
//		index++;
//		if(index>4){
//			index=0;
//		}
//		$("#tt li").eq(index).fadeIn().siblings().fadeOut();
//	}
//})



$(function(){
	var t;
	var index=0;
	t=setInterval(sum,1000);
	function sum(){
		index++;
		if(index>4){
			index=0;
		}
		$("#tt li").eq(index).fadeIn().siblings().fadeOut();
	}
})
	

